package com.example.swifthome

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
